const http = require('node:http');
const server = http.createServer((_req, res) => res.end('machinen-node-level5-detected-v1'));
server.listen(3000, '127.0.0.1');
